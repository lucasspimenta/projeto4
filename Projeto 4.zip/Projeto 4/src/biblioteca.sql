CREATE DATABASE biblioteca;
USE biblioteca;

CREATE TABLE livros (
    idlivro INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(255) NOT NULL,
    autor VARCHAR(100),
    ano VARCHAR(10)
);

-- Tabela para armazenar informações dos usuários
CREATE TABLE usuarios (
    idusuario INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(255)
);

-- Tabela para registrar os empréstimos realizados
CREATE TABLE emprestimos (
    idemprestimos INT AUTO_INCREMENT PRIMARY KEY,
    idlivro INT NOT NULL,
    idusuario INT NOT NULL,
    devolvido BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (idlivro) REFERENCES livros(idlivro),
    FOREIGN KEY (idusuario) REFERENCES usuarios(idusuario)
);

SELECT * FROM emprestimos